import {build} from 'esbuild';
import {mkdir,rm} from 'node:fs/promises';
import assert from 'node:assert/strict';
await mkdir('.sites-runtime/auth-tests',{recursive:true});
try{
globalThis.authTestEnv={DB:{prepare(){return {bind(email){return {first:async()=>email==='invited@example.test'?{id:'verified-invite'}:null}}}}}};
await build({entryPoints:['app/chatgpt-auth.ts'],outfile:'.sites-runtime/auth-tests/auth.mjs',bundle:true,platform:'node',format:'esm',plugins:[{name:'headers',setup(b){b.onResolve({filter:/^cloudflare:workers$/},()=>({path:'env',namespace:'test'}));b.onResolve({filter:/^next\/(headers|navigation)$/},a=>({path:a.path,namespace:'test'}));b.onLoad({filter:/.*/,namespace:'test'},a=>({contents:a.path==='env'?'export const env=globalThis.authTestEnv':a.path==='next/headers'?'export async function headers(){return globalThis.testHeaders}':'export function redirect(url){throw new Error("REDIRECT "+url)}'}))}}]});
const {getChatGPTUser,requireChatGPTUser}=await import('../.sites-runtime/auth-tests/auth.mjs');
const {workspaceOwner:o}=await import('../app/workspace-owner.ts');
let count=0;const check=(ok,label)=>{assert.ok(ok,label);console.log('PASS '+label);count++};
globalThis.testHeaders=new Headers();check(await getChatGPTUser()===null,'anonymous remains denied');
globalThis.testHeaders=new Headers({'oai-authenticated-user-email':o.email});check(await getChatGPTUser()===null,'email alone is insufficient');
globalThis.testHeaders=new Headers({'oai-authenticated-user-email':'unknown@example.test','x-dispatched-app':o.dispatchApp});check(await getChatGPTUser()===null,'unlisted email cannot use compatibility path');
globalThis.testHeaders=new Headers({'oai-authenticated-user-email':o.email,'x-dispatched-app':o.dispatchApp});check((await requireChatGPTUser('/')).userId===o.accountId,'verified private owner enters without broken redirect');
globalThis.testHeaders.set('oai-authenticated-user-id','future-subject');check((await getChatGPTUser()).userId===o.accountId,'owner key remains stable when subject becomes available');
globalThis.testHeaders=new Headers({'oai-authenticated-user-email':'staff@example.test','oai-authenticated-user-id':'staff-id'});check((await getChatGPTUser()).userId==='staff-id','standard staff identity preserved');
globalThis.testHeaders=new Headers({'oai-authenticated-user-email':'invited@example.test','x-dispatched-app':o.dispatchApp});check((await getChatGPTUser()).userId==='member:verified-invite','explicitly invited staff enters workspace without subject');
console.log('Verified '+count+' authentication checks');
}finally{await rm('.sites-runtime/auth-tests',{recursive:true,force:true})}

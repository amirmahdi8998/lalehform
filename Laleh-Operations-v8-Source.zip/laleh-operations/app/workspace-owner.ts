/** Server-only mapping from the verified Sites owner access policy. */
export const workspaceOwner = {
  "email": "amirmahdi.ghaffari89@gmail.com",
  "accountId": "8dd9183c-e8c1-40e6-8944-0d25725c56d9",
  "dispatchApp": "site---6aa1a4a8b0c081919426c311674192cc"
} as const;


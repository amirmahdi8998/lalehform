'use client';
import {MotionConfig,motion,useReducedMotion} from 'framer-motion';
import type {ReactNode} from 'react';
export function MotionShell({children}:{children:ReactNode}){return <MotionConfig reducedMotion="user" transition={{duration:0.22,ease:[0.22,1,0.36,1]}}>{children}</MotionConfig>}
export function PageMotion({children,page}:{children:ReactNode;page:string}){const reduce=useReducedMotion();return <motion.main key={page} className="main" initial={{opacity:0,y:reduce?0:10}} animate={{opacity:1,y:0}} transition={{duration:reduce?0:0.24}}>{children}</motion.main>}

export const roleNames=['مالک','مدیر هتل','مدیر شیفت','مدیر بخش','سرپرست','کارمند','ناظر'];
export const capabilityNames={write:'ثبت و ویرایش',approve:'تأیید و بازگشایی',export:'خروجی گزارش',team:'مدیریت اعضا',configure:'تنظیم قواعد',critical:'اعلام سطح ۴ و ۵'};
export type Capability=keyof typeof capabilityNames;
export type Profile={role:string;department:string;name:string;userId?:string;permissions?:Record<Capability,boolean>};
export function rolePermissions(role:string):Record<Capability,boolean>{return {write:roleNames.includes(role)&&role!=='ناظر',approve:['مالک','مدیر هتل','مدیر شیفت','مدیر بخش','سرپرست'].includes(role),export:['مالک','مدیر هتل','مدیر شیفت','مدیر بخش','سرپرست'].includes(role),team:role==='مالک',configure:['مالک','مدیر هتل'].includes(role),critical:['مالک','مدیر هتل','مدیر شیفت','مدیر بخش','سرپرست'].includes(role)}}
export function allowed(p:Profile,key:Capability){return p.permissions?.[key]??rolePermissions(p.role)[key]}
export function mayDelete(p:Profile,r:{kind:string;department:string;level:number}){return allowed(p,'write')&&allowed(p,'approve')&&!['room','staff','rule'].includes(r.kind)&&(['مالک','مدیر هتل','مدیر شیفت'].includes(p.role)||(['مدیر بخش','سرپرست'].includes(p.role)&&r.department===p.department))&&(r.level<4||allowed(p,'critical'))}

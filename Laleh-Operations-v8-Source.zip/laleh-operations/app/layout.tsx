import type { Metadata } from "next";
import "./globals.css";
import "./redesign.css";
import "./forms.css";
import "./ambience.css";
import "./refinements.css";

export const metadata: Metadata = {
  title: "لاله | مرکز عملیات هتل",
  description: "سامانه یکپارچه عملیات، فرم‌های دیجیتال و مدیریت رویدادهای هتل لاله",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "لاله", statusBarStyle: "default" },
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/laleh-logo-monogram.png",
    shortcut: "/laleh-logo-monogram.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl">
      <body className="antialiased">{children}</body>
    </html>
  );
}

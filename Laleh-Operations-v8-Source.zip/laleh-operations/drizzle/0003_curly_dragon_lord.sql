CREATE TABLE `comments` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`record_id` text NOT NULL,
	`body` text NOT NULL,
	`actor` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_comments_owner_record` ON `comments` (`owner`,`record_id`);--> statement-breakpoint
ALTER TABLE `members` ADD `permissions` text DEFAULT '{}' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_audit_owner_created` ON `audit` (`owner`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_records_owner_kind` ON `records` (`owner`,`kind`);
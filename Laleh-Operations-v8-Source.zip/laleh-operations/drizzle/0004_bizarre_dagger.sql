CREATE TABLE `deleted_records` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`payload` text NOT NULL,
	`deleted_by` text NOT NULL,
	`deleted_at` text NOT NULL,
	`reason` text NOT NULL
);

# Laleh Hotel Operations

Persian RTL hotel operations application using React/Vinext, Cloudflare D1/R2 and Drizzle. Includes supplied Laleh logo assets and locally served Vazirmatn font.

## Implemented

Dashboard, five-level incidents, responsibility and arrival acknowledgements, room board, housekeeping inspections, laundry quantities and stages, maintenance, reception requests, kitchen checks, security patrols, inventory requests, lost property, shift handover and team management.

Forms persist on the server with audit history and optimistic concurrency checks. Supports filtering, CSV reports with formula neutralization, authorized PDF/PNG/JPEG attachments (8 MB each, 10 per record), removable sample records, and responsive Persian screens.

Owner provisions staff by sign-in email. Employee and supervisor access is scoped to departments; manager roles span the workspace. Membership management is owner-only. Revocation and inspection permissions are enforced on the server. Site sharing must separately allow each employee to reach the application; initial publication is owner-private. One membership per email is supported in this Site.

The home-screen manifest and service worker do not cache operational records or authenticated pages. In-app incident notices are detected during 30-second polling while the app is open.

## Operations journal redesign

The work surface now includes a floor ledger, five-level incident watch, contextual department desks, task boards and laundry stages, staff roster and permission matrix. The shared case workflow supports start, submit, approve, return for correction, reopen and persistent comments. Housekeeping transitions update a linked room atomically with revision guards. Daily and turndown service preserve occupied-room status; checkout/arrival cleaning still blocks occupied or out-of-service rooms. General form edits cannot bypass the case workflow.

Owner-managed per-member approve/export/critical overrides are persisted and enforced server-side. Observers cannot mutate records or attachments. CSV exports now run server-side, respect record scope and create audit entries. Workspace-header compatibility supports only the verified owner and explicitly provisioned staff; unknown email-only identities remain denied.

`node tests/auth-check.mjs` covers seven identity boundary cases. Browser/device QA was not requested or performed in this turn.

## Not yet connected

External push, SMS and phone providers are not connected. Level five does not ring a phone. Escalation rules store policy but timed automatic dispatch is not active. Production alert delivery requires provider credentials, verified senders, a durable dispatch service with retry/callback handling and recipient device testing.

Three hotel paper forms have been supplied and implemented (repair request, floor room check, and night reception occupancy report). Remaining SOPs and actual staff/room inventories still need hotel review before mandatory paper records are retired. Guest reservations, billing/POS/PMS integration, payroll, certified signatures, a stock ledger and offline submission queues are outside the implemented workflows.

Before operational rollout: approve staff access, configure actual notification providers, agree on retention/backups, verify restore/monitoring and perform browser/device and load acceptance tests. This review release is not a certified emergency paging system.

## Validation

`node tests/api-check.mjs`: 151 checks against local D1/R2 emulation and actual bundled API handlers. Covers authentication, tenant separation, domain validation, concurrent edits, audit consistency, file authorization, sample cleanup, membership provisioning and revocation. No real notification is sent.

`npx tsc --noEmit`: TypeScript validation.

Migrations reside in `drizzle/`; logical bindings in `.openai/hosting.json`. Browser and device QA have not been performed.

## Department-specific forms and supplied paper records

34 prepared forms now have separate schemas, defaults, required inputs and follow-up sections. Title, department and initial status are automatic; staff choose a prepared workflow in their authorized department. Persian/Arabic digits and negative decimal temperatures are supported. Checklist completion is required at submission, not initial registration. Legacy records remain readable and editable.

The supplied repair form records the requested work, paper reference, server-generated request number, requester and preparation time, start/finish timestamps, technician, remarks and authenticated confirmation attribution. This confirmation is an account action in the audit trail, not a certified or handwritten signature.

The floor Room Check form records the Persian date, floor, morning/afternoon round, time, and multiple room/guest/code rows using the supplied four-code legend. The night report records rooms by floor or cabana, guest counts and prices in an explicitly labeled currency, corrections, half-day rooms and computed summaries. Room lists are imported on demand from configured rooms; blurry source images are not treated as authoritative room inventory. Blank counts and rates remain unreported rather than being assumed zero. Reports snapshot entered observations; they do not automatically rewrite room status or charge guest accounts.

Table payloads are validated server-side, persisted with revision guards, included in authorized exports, and rendered again in the saved record. Reception can read the room register for report preparation but cannot edit housekeeping room records. No schema migration was needed for the additional JSON payload fields.

## Visual ambience

The operations masthead uses an adapted React Bits Waves canvas (David Haz), styled in the hotel's brass/plum palette. Source: https://github.com/DavidHDev/react-bits/tree/main/src/ts-default/Backgrounds/Waves . The upstream MIT + Commons Clause notice is shipped at public/licenses/react-bits.txt. The adaptation caps rendering at 30 FPS and device pixel ratio at 1.5, pauses while hidden or outside the viewport, respects reduced-motion preferences and offers a manual pause control. No new runtime dependency or backend/data-storage change is involved.

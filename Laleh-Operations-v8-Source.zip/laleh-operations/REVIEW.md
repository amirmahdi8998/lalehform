# Operations review — 2026-09-16

Scope: source and executable API review of employee, supervisor, hotel-manager and owner workflows; D1 persistence, R2 attachment authorization, form lifecycle, and UI interaction refinements. This is not an independent penetration test, browser/device QA, or production-readiness certification.

## Corrected findings

- Unprovisioned authenticated identities no longer default to owner. Only the canonical workspace owner or explicitly provisioned active members are admitted. Unknown membership roles fail closed; unknown roles have no export permission.
- Record kinds must be own properties of the form registry. Legacy departmental forms cannot masquerade as another department for non-management users.
- Operational records awaiting approval or completed cannot be silently edited; return/reopen is required. Laundry stages are workflow-only, including legacy forms, and cannot advance in review/completed states.
- Reopening housekeeping clears previous inspection and attribution, allowing employees to correct the reopened work.
- Authentication/database failures in records APIs now use the handled service-error path. Export validates IDs and handles malformed JSON; CSV formula escaping includes leading whitespace.
- Revoked access clears loaded records, details, editors and profile on the next refresh. Out-of-order refresh responses are ignored. A synchronous mutation lock prevents repeated submissions while a mutation is active.

## Experience changes

- Real Framer Motion integration: page entry, work-card entry/hover, room-button feedback and staggered queue rows, respecting reduced-motion settings.
- Existing branded ReactBits background retained, including pause control.
- Persian/Arabic/Latin number search and Persian letter normalization.
- Visible last-sync/offline/error/saving status, focus outlines, locked-form explanation, corrected handover shortcut and laundry action availability.
- Background polling pauses in hidden/offline tabs; initial/manual refresh remains available.

## Verification

168 API/persistence assertions run against local Miniflare D1 and R2 with mocked platform identity, including all 34 prepared form schemas, membership revocation, tenant/department isolation, attachments, concurrency, workflow approvals and new regressions. 7 separate authentication boundary checks. TypeScript and production build checked before publishing. No browser/device visual assessment performed in this review.

## Operating limits and remaining decisions

- D1 is the authoritative record/member/audit store; attachments use R2. Browser localStorage is not the operational database.
- Site audience remains owner-private. Creating an in-app staff member does not grant access through the outer Site sharing boundary. Staff rollout needs an explicitly authorized audience change.
- Push, SMS, telephone escalation, background emergency delivery and wake-from-silent behavior are not connected or guaranteed. Configured escalation rules do not constitute an active dispatch service.
- No offline submissions. No load test, backup restoration drill, independent security assessment, or real-device acceptance test has been completed.
- Incidents are visible hotel-wide and writable by authorized writers under the existing incident policy. Organization-specific incident ownership/assignment policy should be agreed before staff rollout.
- R2 attachment count is checked before insert; strict concurrency-safe quotas remain an improvement. Current APIs read tenant data before filtering for some listings/exports; benchmark and pagination are needed for large deployments.

## Pre-presentation review — 2026-09-20

Added per-task deletion to work cards, tables and record details. A confirmation and reason are required. Owner/hotel/shift managers can delete operational records; department managers and supervisors need approval permission and matching department. Critical records also require critical permission. Room, staff and rule masters are excluded from this task operation.

Deletion atomically archives the record snapshot, actor, timestamp and reason, adds an audit event, then removes the active record with revision checking. Comments and attachment evidence are retained but inaccessible through normal record endpoints after deletion. There is no archive restore UI yet. Deleting housekeeping work does not silently change its room state. No existing production records were deleted by this review.

Additional fixes: obsolete incident toasts dismiss after deletion/completion; visible export/sample-clear actions reflect permissions; attachment insertion atomically enforces the ten-file quota and checks the parent still exists, cleaning up rejected uploads; attachment authentication/database errors return handled responses.

Verification now covers 187 API/persistence assertions and 7 authentication assertions, including repeated/concurrent deletion, cross-tenant and employee denial, revision conflicts, deleted-record access, archive/audit preservation and concurrent attachment quotas. TypeScript and production build checked. Browser/device acceptance testing remains outstanding. Previous attachment-quota concurrency limitation above is resolved. Previous external-notification, sharing, backup/load-test and incident policy limitations remain applicable.
